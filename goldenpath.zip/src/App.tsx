import React, { useState, useCallback, useEffect, useRef } from 'react';
import { useDropzone } from 'react-dropzone';
import { 
  Upload, 
  Settings, 
  Play, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Key, 
  ChevronRight,
  Loader2,
  Trash2,
  Copy,
  Check,
  RotateCcw,
  History,
  Save,
  Github,
  BookOpen,
  Users,
  MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { processBatch } from './lib/gemini';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Batch {
  id: number;
  content: string;
  status: 'pending' | 'processing' | 'completed' | 'error' | 'retrying';
  result?: string;
  retryAttempt?: number;
  retryDelay?: number;
}

const STORAGE_KEY = 'chat_distiller_session';

const MODES = [
  {
    id: 'distiller',
    name: 'GoldenPath Distiller',
    icon: MessageSquare,
    description: 'Prune dead ends and extract the "Golden Path" from technical logs.',
    prompt: `You are an expert technical archivist. Your goal is to extract a "Golden Path" from a messy, iterative troubleshooting session.

CURRENT SUMMARY (The cumulative working state so far):
{{previousSummary}}

PREVIOUS BATCH (Raw context from the last batch for continuity):
{{previousBatch}}

NEW CONVERSATION BATCH (The new raw data to process):
{{currentBatch}}

TASK:
1. IDENTIFY SUCCESS VS FAILURE: Look for errors or "that didn't work" messages in the new batch.
2. SUPERSEDE OLD INFO: If the new batch contains a fix for a problem encountered in the previous summary, DELETE the failed instruction from the summary and replace it with the new working one.
3. CASCADE UPDATES (BACKTRACKING): If a change in the new batch invalidates or modifies a "foundational" step earlier in the summary (e.g., changing a config in Step 2 that affects Step 5), you MUST update all subsequent steps in the summary to maintain technical consistency.
4. PRUNE DEAD ENDS: Completely discard any commands, patches, or suggestions that were explicitly stated as failing or being replaced.
5. DISCARD NOISE: Ignore long logs (e.g., tensor processing, build logs, error traces) unless they are critical to understanding a failure that was later fixed. Even then, summarize the failure briefly and focus on the fix.
6. CONSOLIDATE CODE: If multiple patches are applied to the same file across batches, represent the final, cumulative state of that file or the sequence of commands that leads to the current success.
7. STRIP FLUFF: Remove conversational filler ("You're doing great", "Silence of success"). Keep only the technical "How-To".

OUTPUT: A clean, cumulative "Final Working Instructions" document. If the session is still in a failing state at the end of this batch, clearly mark the last known error and the proposed (but unverified) fix.`
  },
  {
    id: 'minutes',
    name: 'Meeting Minutes & Tasks',
    icon: Users,
    description: 'Extract executive summaries and action items from long transcripts.',
    prompt: `You are an expert executive assistant. Your goal is to distill a long meeting transcript into a structured summary and a clear list of action items.

CURRENT SUMMARY (The cumulative working state so far):
{{previousSummary}}

PREVIOUS BATCH (Raw context from the last batch for continuity):
{{previousBatch}}

NEW CONVERSATION BATCH (The new raw data to process):
{{currentBatch}}

TASK:
1. SUMMARIZE KEY POINTS: Extract the core decisions and topics discussed in the new batch.
2. UPDATE ACTION ITEMS: Maintain a running list of "Action Items." If a task is assigned, add it. If a task is completed or cancelled later in the transcript, update the list accordingly.
3. IDENTIFY OWNERS: Clearly attribute each action item to a person or team if mentioned.
4. MAINTAIN CONTEXT: If a discussion in the new batch clarifies or changes a decision made earlier in the transcript (found in the summary), update the summary to reflect the final consensus.
5. DISCARD SMALL TALK: Ignore greetings, off-topic banter, and administrative filler.

OUTPUT:
- EXECUTIVE SUMMARY: A high-level overview of the meeting's progress.
- ACTION ITEMS: A categorized list of tasks, owners, and deadlines.`
  },
  {
    id: 'docs',
    name: 'Technical Doc Generator',
    icon: BookOpen,
    description: 'Synthesize raw code notes and logs into structured technical docs.',
    prompt: `You are an expert technical writer. Your goal is to synthesize raw developer notes, logs, and code snippets into a structured "System Architecture" or "API Documentation" document.

CURRENT SUMMARY (The cumulative working state so far):
{{previousSummary}}

PREVIOUS BATCH (Raw context from the last batch for continuity):
{{previousBatch}}

NEW CONVERSATION BATCH (The new raw data to process):
{{currentBatch}}

TASK:
1. EXTRACT ARCHITECTURE: Identify components, data flows, and dependencies mentioned in the new batch.
2. DOCUMENT APIS: If endpoints, parameters, or response schemas are mentioned, add them to a structured "API Reference" section.
3. CONSOLIDATE KNOWLEDGE: If the new batch provides more detail on a component already in the summary, enrich the existing documentation rather than creating a duplicate section.
4. MAINTAIN CONSISTENCY: Ensure naming conventions and technical descriptions are consistent across the entire document.
5. STRIP NOISE: Ignore debugging logs, temporary workarounds, and conversational context.

OUTPUT: A structured, professional technical document (Markdown format).`
  }
];

const DEFAULT_PROMPT = MODES[0].prompt;

export default function App() {
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('gemini_api_key') || '');
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [batchSize, setBatchSize] = useState(4);
  const [tokenCeiling, setTokenCeiling] = useState(8192); // Approx tokens (chars / 4)
  const [currentMode, setCurrentMode] = useState(MODES[0].id);
  const [promptTemplate, setPromptTemplate] = useState(DEFAULT_PROMPT);
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);
  const [apiStatus, setApiStatus] = useState<'healthy' | 'quota_limit' | 'error' | 'idle'>('idle');
  
  const [batches, setBatches] = useState<Batch[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentSummary, setCurrentSummary] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [hasSavedSession, setHasSavedSession] = useState(false);
  const [backoffLevel, setBackoffLevel] = useState(0);
  const [cooldownTime, setCooldownTime] = useState(0);
  const errorRef = useRef<HTMLDivElement>(null);

  const parsedError = React.useMemo(() => {
    if (!error) return null;
    try {
      const parsed = JSON.parse(error);
      if (parsed.error) return parsed.error;
    } catch (e) {}
    return { message: error };
  }, [error]);

  // Retry countdown timer
  useEffect(() => {
    const interval = setInterval(() => {
      setBatches(prev => prev.map(b => {
        if (b.status === 'retrying' && b.retryDelay && b.retryDelay > 0) {
          return { ...b, retryDelay: b.retryDelay - 1 };
        }
        return b;
      }));
      setCooldownTime(prev => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Load saved session on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setHasSavedSession(true);
      const session = JSON.parse(saved);
      if (session.promptTemplate) setPromptTemplate(session.promptTemplate);
      if (session.tokenCeiling) setTokenCeiling(session.tokenCeiling);
    }
  }, []);

  // Save API key
  useEffect(() => {
    localStorage.setItem('gemini_api_key', apiKey);
  }, [apiKey]);

  // Auto-save session
  useEffect(() => {
    if (batches.length > 0) {
      const session = {
        fileName,
        fileContent,
        batchSize,
        tokenCeiling,
        promptTemplate,
        currentMode,
        batches,
        currentSummary
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
      setHasSavedSession(true);
    }
  }, [batches, currentSummary, fileName, fileContent, batchSize, tokenCeiling, promptTemplate, currentMode]);

  const loadSession = () => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const session = JSON.parse(saved);
      setFileName(session.fileName);
      setFileContent(session.fileContent);
      setBatchSize(session.batchSize);
      setTokenCeiling(session.tokenCeiling || 8192);
      setPromptTemplate(session.promptTemplate || DEFAULT_PROMPT);
      setCurrentMode(session.currentMode || MODES[0].id);
      setBatches(session.batches);
      setCurrentSummary(session.currentSummary);
      setHasSavedSession(true);
    }
  };

  const clearSession = () => {
    localStorage.removeItem(STORAGE_KEY);
    setHasSavedSession(false);
    reset();
  };

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        setFileContent(text);
        createBatches(text, batchSize, tokenCeiling);
      };
      reader.readAsText(file);
    }
  }, [batchSize, tokenCeiling]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'text/plain': ['.txt', '.log', '.md'] },
    multiple: false
  } as any);

  const createBatches = (text: string, size: number, ceiling: number) => {
    const turns = text.split(/(?=User:|Gemini:|Human:|Assistant:)/i);
    const newBatches: Batch[] = [];
    
    const charCeiling = ceiling * 4; // Rough heuristic: 4 chars per token

    if (turns.length <= 1) {
      const lines = text.split('\n').filter(l => l.trim());
      let currentBatchContent = '';
      let currentBatchId = 0;

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i] + '\n';
        if ((currentBatchContent.length + line.length > charCeiling) && currentBatchContent.length > 0) {
          newBatches.push({ id: currentBatchId++, content: currentBatchContent, status: 'pending' });
          currentBatchContent = line;
        } else {
          currentBatchContent += line;
        }
      }
      if (currentBatchContent) {
        newBatches.push({ id: currentBatchId, content: currentBatchContent, status: 'pending' });
      }
    } else {
      let currentBatchContent = '';
      let currentBatchTurns = 0;
      let currentBatchId = 0;

      for (let i = 0; i < turns.length; i++) {
        let turn = turns[i];
        
        // If a single turn is larger than the ceiling, we must split it
        if (turn.length > charCeiling) {
          // Flush current batch if not empty
          if (currentBatchContent.length > 0) {
            newBatches.push({ id: currentBatchId++, content: currentBatchContent, status: 'pending' });
            currentBatchContent = '';
            currentBatchTurns = 0;
          }
          
          // Split the giant turn into chunks
          for (let j = 0; j < turn.length; j += charCeiling) {
            newBatches.push({ 
              id: currentBatchId++, 
              content: turn.substring(j, j + charCeiling), 
              status: 'pending' 
            });
          }
          continue;
        }

        const wouldExceedCeiling = currentBatchContent.length + turn.length > charCeiling;
        const wouldExceedSize = currentBatchTurns + 1 > size;

        if ((wouldExceedCeiling || wouldExceedSize) && currentBatchContent.length > 0) {
          newBatches.push({ id: currentBatchId++, content: currentBatchContent, status: 'pending' });
          currentBatchContent = turn;
          currentBatchTurns = 1;
        } else {
          currentBatchContent += turn;
          currentBatchTurns++;
        }
      }
      if (currentBatchContent) {
        newBatches.push({ id: currentBatchId, content: currentBatchContent, status: 'pending' });
      }
    }
    setBatches(newBatches);
    setCurrentSummary('');
    setError(null);
  };

  const startProcessing = async () => {
    if (!apiKey) {
      setError('Please provide a Gemini API Key.');
      return;
    }
    if (batches.length === 0) {
      setError('Please upload a chat log first.');
      return;
    }

    setIsProcessing(true);
    setError(null);
    setApiStatus('healthy');
    
    const firstPendingIndex = batches.findIndex(b => b.status === 'pending' || b.status === 'error');
    if (firstPendingIndex === -1) {
      setIsProcessing(false);
      return;
    }

    let runningSummary = currentSummary;

    try {
      for (let i = firstPendingIndex; i < batches.length; i++) {
        // Pre-emptive cooling down if we hit a rate limit previously
        if (backoffLevel > 0) {
          const waitTime = Math.pow(2, backoffLevel) * 1000;
          setCooldownTime(Math.round(waitTime / 1000));
          setApiStatus('quota_limit');
          await new Promise(resolve => setTimeout(resolve, waitTime));
        }

        setBatches(prev => prev.map((b, idx) => 
          idx === i ? { ...b, status: 'processing', retryAttempt: 0, retryDelay: 0 } : b
        ));

        const result = await processBatch(
          apiKey,
          runningSummary,
          i > 0 ? batches[i-1].content : "",
          batches[i].content,
          i,
          batches.length,
          promptTemplate,
          (attempt, delay) => {
            setApiStatus('quota_limit');
            setBackoffLevel(prev => Math.max(prev, attempt));
            setBatches(prev => prev.map((b, idx) => 
              idx === i ? { ...b, status: 'retrying', retryAttempt: attempt, retryDelay: Math.round(delay / 1000) } : b
            ));
          }
        );

        setApiStatus('healthy');
        // Success: Gradually decrease backoff level
        setBackoffLevel(prev => Math.max(0, prev - 1));
        
        runningSummary = result.text;
        setCurrentSummary(result.text);
        
        setBatches(prev => prev.map((b, idx) => 
          idx === i ? { ...b, status: 'completed', result: result.text } : b
        ));
      }
    } catch (err: any) {
      setApiStatus('error');
      setError(err.message || 'An error occurred during processing.');
      setBatches(prev => prev.map(b => 
        b.status === 'processing' || b.status === 'retrying' ? { ...b, status: 'error' } : b
      ));
    } finally {
      setIsProcessing(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(currentSummary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const reset = () => {
    setFileContent(null);
    setFileName(null);
    setBatches([]);
    setCurrentSummary('');
    setError(null);
  };

  const completedCount = batches.filter(b => b.status === 'completed').length;
  const progress = batches.length > 0 ? (completedCount / batches.length) * 100 : 0;
  const retryingBatch = batches.find(b => b.status === 'retrying');

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-zinc-100 font-sans selection:bg-blue-500/30">
      {/* API Health Badge */}
      <div className="fixed top-6 right-6 z-50 flex items-center gap-3">
        <a 
          href="https://github.com/larrycai/chat-log-distiller" 
          target="_blank" 
          rel="noopener noreferrer"
          className="p-2 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-500 hover:text-white hover:bg-zinc-800 transition-all shadow-lg"
          title="View on GitHub"
        >
          <Github className="w-4 h-4" />
        </a>
        <button 
          onClick={() => {
            if (apiStatus === 'error' || apiStatus === 'quota_limit') {
              errorRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
          }}
          className={cn(
            "flex items-center gap-2 px-3 py-1.5 rounded-full border text-[10px] font-bold tracking-widest uppercase backdrop-blur-md transition-all duration-500",
            apiStatus === 'healthy' ? "bg-green-500/10 border-green-500/20 text-green-400 shadow-[0_0_15px_rgba(34,197,94,0.1)]" :
            apiStatus === 'quota_limit' ? "bg-amber-500/10 border-amber-500/20 text-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.1)]" :
            apiStatus === 'error' ? "bg-red-500/10 border-red-500/20 text-red-400 shadow-[0_0_15px_rgba(239,68,68,0.1)]" :
            "bg-zinc-900/50 border-zinc-800 text-zinc-500",
            (apiStatus === 'error' || apiStatus === 'quota_limit') && "cursor-pointer hover:scale-105 active:scale-95"
          )}
        >
          <div className={cn(
            "w-1.5 h-1.5 rounded-full",
            apiStatus === 'healthy' ? "bg-green-500 animate-pulse" :
            apiStatus === 'quota_limit' ? "bg-amber-500 animate-bounce" :
            apiStatus === 'error' ? "bg-red-500" :
            "bg-zinc-700"
          )} />
          <span>API: {apiStatus.replace('_', ' ')}</span>
          {apiStatus === 'quota_limit' && (retryingBatch || cooldownTime > 0) && (
            <span className="ml-2 pl-2 border-l border-amber-500/30 text-amber-500/80">
              {cooldownTime > 0 ? `Cooling down: ${cooldownTime}s` : `Retry #${retryingBatch?.retryAttempt} in ${retryingBatch?.retryDelay}s`}
            </span>
          )}
        </button>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12">
        {/* Header */}
        <header className="mb-12 space-y-4">
          <div className="flex items-center justify-between">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-medium tracking-wider uppercase">
              <Settings className="w-3 h-3" />
              Iterative Compressor
            </div>
            {hasSavedSession && !fileName && (
              <button 
                onClick={loadSession}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-sm font-medium transition-all text-zinc-300"
              >
                <History className="w-4 h-4 text-blue-500" />
                Resume Previous Session
              </button>
            )}
          </div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-white">
            Golden<span className="text-blue-500">Path</span>
          </h1>
          <p className="text-zinc-400 max-w-2xl text-lg leading-relaxed">
            Distill complex, iterative troubleshooting sessions into a single "Golden Path" 
            of verified working instructions, automatically pruning dead ends and failed attempts.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Sidebar: Controls */}
          <div className="lg:col-span-4 space-y-6">
            {/* Mode Selector */}
            <section className="p-6 rounded-2xl bg-zinc-900/50 border border-zinc-800 backdrop-blur-sm space-y-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-zinc-300">
                <Settings className="w-4 h-4 text-blue-500" />
                Processing Mode
              </div>
              <div className="grid grid-cols-1 gap-2">
                {MODES.map(mode => (
                  <button
                    key={mode.id}
                    onClick={() => {
                      setCurrentMode(mode.id);
                      setPromptTemplate(mode.prompt);
                    }}
                    className={cn(
                      "flex items-start gap-3 p-3 rounded-xl border text-left transition-all",
                      currentMode === mode.id 
                        ? "bg-blue-500/10 border-blue-500/40 text-blue-400" 
                        : "bg-zinc-950 border-zinc-800 text-zinc-500 hover:border-zinc-700 hover:bg-zinc-900"
                    )}
                  >
                    <div className={cn(
                      "p-2 rounded-lg shrink-0",
                      currentMode === mode.id ? "bg-blue-500/20 text-blue-400" : "bg-zinc-800 text-zinc-600"
                    )}>
                      <mode.icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold">{mode.name}</p>
                      <p className="text-[10px] opacity-60 leading-tight mt-0.5">{mode.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </section>

            {/* API Key Section */}
            <section className="p-6 rounded-2xl bg-zinc-900/50 border border-zinc-800 backdrop-blur-sm space-y-4 shadow-sm">
              <div className="flex items-center gap-2 text-sm font-semibold text-zinc-300">
                <Key className="w-4 h-4 text-blue-500" />
                Gemini API Key
              </div>
              <div className="relative">
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Enter your API Key..."
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all placeholder:text-zinc-600"
                />
              </div>
            </section>

            {/* Upload Section */}
            <section className="p-6 rounded-2xl bg-zinc-900/50 border border-zinc-800 backdrop-blur-sm space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-semibold text-zinc-300">
                  <FileText className="w-4 h-4 text-blue-500" />
                  Chat Log
                </div>
                {fileName && (
                  <button 
                    onClick={clearSession}
                    title="Clear Session"
                    className="p-1.5 rounded-lg hover:bg-red-500/10 text-zinc-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              {!fileName ? (
                <div 
                  {...getRootProps()} 
                  className={cn(
                    "border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all",
                    isDragActive ? "border-blue-500 bg-blue-500/5" : "border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800/30"
                  )}
                >
                  <input {...getInputProps()} />
                  <Upload className="w-8 h-8 text-zinc-600 mx-auto mb-3" />
                  <p className="text-sm text-zinc-400">
                    {isDragActive ? "Drop the log here" : "Drag & drop log file"}
                  </p>
                  <p className="text-xs text-zinc-600 mt-1">.txt, .log, .md</p>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-zinc-200 truncate">{fileName}</p>
                    <p className="text-xs text-zinc-500">{batches.length} batches created</p>
                  </div>
                </div>
              )}
            </section>

            {/* Advanced Settings */}
            <section className="rounded-2xl bg-zinc-900/50 border border-zinc-800 backdrop-blur-sm overflow-hidden transition-all">
              <button 
                onClick={() => setIsAdvancedOpen(!isAdvancedOpen)}
                className="w-full p-6 flex items-center justify-between text-sm font-semibold text-zinc-300 hover:bg-zinc-800/30 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <Settings className="w-4 h-4 text-blue-500" />
                  Advanced Settings
                </div>
                <ChevronRight className={cn("w-4 h-4 transition-transform", isAdvancedOpen && "rotate-90")} />
              </button>
              
              <AnimatePresence>
                {isAdvancedOpen && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="px-6 pb-6 space-y-6"
                  >
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs text-zinc-500">
                          <span>Turns per batch</span>
                          <span>{batchSize} turns</span>
                        </div>
                        <input
                          type="range"
                          min="1"
                          max="20"
                          value={batchSize}
                          disabled={isProcessing || batches.some(b => b.status === 'completed')}
                          onChange={(e) => {
                            const val = parseInt(e.target.value);
                            setBatchSize(val);
                            if (fileContent) createBatches(fileContent, val, tokenCeiling);
                          }}
                          className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-500 disabled:opacity-50"
                        />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-xs text-zinc-500">
                          <span>Token ceiling per batch</span>
                          <span>~{tokenCeiling} tokens</span>
                        </div>
                        <input
                          type="range"
                          min="1024"
                          max="32768"
                          step="1024"
                          value={tokenCeiling}
                          disabled={isProcessing || batches.some(b => b.status === 'completed')}
                          onChange={(e) => {
                            const val = parseInt(e.target.value);
                            setTokenCeiling(val);
                            if (fileContent) createBatches(fileContent, batchSize, val);
                          }}
                          className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-500 disabled:opacity-50"
                        />
                        <p className="text-[10px] text-zinc-600 italic">
                          Heuristic: 1 token ≈ 4 characters.
                        </p>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center text-xs text-zinc-500">
                          <span>Prompt Template</span>
                          <button 
                            onClick={() => {
                              const mode = MODES.find(m => m.id === currentMode);
                              if (mode) setPromptTemplate(mode.prompt);
                            }}
                            className="flex items-center gap-1 hover:text-blue-400 transition-colors"
                          >
                            <RotateCcw className="w-3 h-3" />
                            Reset to Mode Default
                          </button>
                        </div>
                        <textarea
                          value={promptTemplate}
                          onChange={(e) => setPromptTemplate(e.target.value)}
                          disabled={isProcessing}
                          className="w-full h-48 bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-[10px] font-mono text-zinc-400 focus:outline-none focus:ring-1 focus:ring-blue-500/50 resize-none"
                        />
                        <div className="flex flex-wrap gap-2">
                          {['{{previousSummary}}', '{{previousBatch}}', '{{currentBatch}}', '{{batchIndex}}', '{{totalBatches}}'].map(tag => (
                            <span key={tag} className="px-1.5 py-0.5 rounded bg-zinc-800 text-[9px] text-zinc-500 font-mono">{tag}</span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </section>

            {/* Action Button */}
            <button
              onClick={startProcessing}
              disabled={isProcessing || !fileContent || !apiKey}
              className={cn(
                "w-full py-4 rounded-2xl font-bold text-sm tracking-wide flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-500/10",
                isProcessing || !fileContent || !apiKey
                  ? "bg-zinc-800 text-zinc-500 cursor-not-allowed"
                  : "bg-blue-600 hover:bg-blue-500 text-white active:scale-[0.98]"
              )}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  {completedCount > 0 ? <RotateCcw className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  {completedCount > 0 ? 'Resume Distillation' : 'Start Distillation'}
                </>
              )}
            </button>

            {error && (
              <motion.div 
                ref={errorRef}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 flex items-start gap-3"
              >
                <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-red-400 uppercase tracking-wider">
                      {parsedError?.code ? `API Error ${parsedError.code}` : 'Processing Error'}
                    </p>
                    <p className="text-xs text-zinc-400 leading-relaxed">
                      {parsedError?.message || error}
                    </p>
                    {parsedError?.status === 'RESOURCE_EXHAUSTED' && (
                      <div className="mt-3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                        <p className="text-[10px] text-amber-400 font-medium">
                          Quota exceeded. The system is automatically retrying with exponential backoff.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
                <button 
                  onClick={() => setError(null)}
                  className="p-1 rounded-lg hover:bg-white/5 text-zinc-500 transition-colors"
                  title="Dismiss Error"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </motion.div>
            )}
          </div>

          {/* Main Content: Progress & Results */}
          <div className="lg:col-span-8 space-y-6">
            {/* Progress Bar */}
            {batches.length > 0 && (
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-medium text-zinc-500 px-1">
                  <span>Overall Progress</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="h-2 w-full bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    className="h-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]"
                  />
                </div>
              </div>
            )}

            {/* Summary View */}
            <section className="min-h-[400px] rounded-2xl bg-zinc-900/50 border border-zinc-800 backdrop-blur-sm overflow-hidden flex flex-col">
              <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/80 backdrop-blur-md">
                <div className="flex items-center gap-2 text-sm font-semibold text-zinc-300">
                  <CheckCircle2 className="w-4 h-4 text-blue-500" />
                  Distilled Knowledge
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-zinc-800/50 text-[10px] text-zinc-500 border border-zinc-800">
                    <Save className="w-3 h-3" />
                    Auto-saved
                  </div>
                  {currentSummary && (
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => {
                          if (window.confirm('Are you sure you want to clear the distilled knowledge? This will not delete the uploaded file or batches.')) {
                            setCurrentSummary('');
                          }
                        }}
                        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-red-500/10 text-zinc-500 hover:text-red-400 text-xs font-medium transition-all"
                        title="Clear Summary"
                      >
                        <Trash2 className="w-3 h-3" />
                        Clear
                      </button>
                      <button 
                        onClick={copyToClipboard}
                        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium transition-all"
                      >
                      {copied ? (
                        <>
                          <Check className="w-3 h-3 text-green-500" />
                          Copied
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          Copy
                        </>
                      )}
                    </button>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex-1 p-6 font-mono text-sm leading-relaxed text-zinc-300 whitespace-pre-wrap overflow-y-auto max-h-[600px]">
                {currentSummary ? (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    {currentSummary}
                  </motion.div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-zinc-600 space-y-4">
                    <div className="w-16 h-16 rounded-full bg-zinc-800/50 flex items-center justify-center">
                      <FileText className="w-8 h-8 opacity-20" />
                    </div>
                    <p className="text-center max-w-xs">
                      The distilled summary will appear here as batches are processed.
                    </p>
                  </div>
                )}
              </div>
            </section>

            {/* Batch Progress List */}
            {batches.length > 0 && (
              <section className="space-y-3">
                <h3 className="text-sm font-semibold text-zinc-400 px-1">Processing Queue</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
                  {batches.map((batch, idx) => (
                    <div 
                      key={batch.id}
                      className={cn(
                        "p-3 rounded-xl border text-center transition-all relative group",
                        batch.status === 'completed' ? "bg-green-500/5 border-green-500/20 text-green-400" :
                        batch.status === 'processing' ? "bg-blue-500/5 border-blue-500/40 text-blue-400 animate-pulse" :
                        batch.status === 'retrying' ? "bg-amber-500/5 border-amber-500/40 text-amber-400" :
                        batch.status === 'error' ? "bg-red-500/5 border-red-500/20 text-red-400" :
                        "bg-zinc-900/50 border-zinc-800 text-zinc-600"
                      )}
                    >
                      <div className="text-[10px] font-bold uppercase tracking-widest mb-1">Batch</div>
                      <div className="text-lg font-bold">{idx + 1}</div>
                      <div className="mt-1">
                        {batch.status === 'completed' && <CheckCircle2 className="w-3 h-3 mx-auto" />}
                        {batch.status === 'processing' && <Loader2 className="w-3 h-3 mx-auto animate-spin" />}
                        {batch.status === 'retrying' && (
                          <div className="flex flex-col items-center gap-1">
                            <RotateCcw className="w-3 h-3 animate-spin" />
                            <span className="text-[8px] font-bold">Retry {batch.retryAttempt} ({batch.retryDelay}s)</span>
                          </div>
                        )}
                        {batch.status === 'error' && <AlertCircle className="w-3 h-3 mx-auto" />}
                        {batch.status === 'pending' && <div className="w-1.5 h-1.5 rounded-full bg-zinc-800 mx-auto" />}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
