import { GoogleGenAI, Type } from "@google/genai";

export interface BatchResult {
  text: string;
  attempts: number;
}

export async function processBatch(
  apiKey: string,
  previousSummary: string,
  previousBatchContent: string,
  currentBatch: string,
  batchIndex: number,
  totalBatches: number,
  promptTemplate: string,
  onRetry?: (attempt: number, delay: number) => void
): Promise<BatchResult> {
  const ai = new GoogleGenAI({ apiKey });
  
  const prompt = promptTemplate
    .replace('{{previousSummary}}', previousSummary || "None yet.")
    .replace('{{previousBatch}}', previousBatchContent || "This is the first batch.")
    .replace('{{currentBatch}}', currentBatch)
    .replace('{{batchIndex}}', (batchIndex + 1).toString())
    .replace('{{totalBatches}}', totalBatches.toString());

  const maxRetries = 5;
  let attempt = 0;

  while (attempt < maxRetries) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          systemInstruction: "You are a technical archivist. Your goal is to maintain a cumulative 'Golden Path' document. You must be aggressive in removing failed instructions and replacing them with working ones found in later conversation batches. Focus on technical accuracy and instruction-oriented output.",
        }
      });

      if (!response.text) {
        throw new Error("Empty response from Gemini.");
      }

      return { text: response.text, attempts: attempt };
    } catch (error: any) {
      attempt++;
      if (attempt >= maxRetries) {
        throw error;
      }

      const isRateLimit = error.message?.includes('429') || error.status === 429 || error.message?.toLowerCase().includes('quota');
      const isServerError = error.status >= 500 || error.message?.includes('500');

      if (isRateLimit || isServerError) {
        const delay = Math.pow(2, attempt) * 1000 + Math.random() * 1000;
        if (onRetry) onRetry(attempt, delay);
        await new Promise(resolve => setTimeout(resolve, delay));
      } else {
        throw error;
      }
    }
  }

  throw new Error("Max retries exceeded.");
}
