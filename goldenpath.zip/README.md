# GoldenPath 🛠️

**Distill messy, iterative technical conversations into a clean "Golden Path" of verified instructions.**

Built with **React**, **Tailwind CSS**, and **Gemini 3 Flash**, **GoldenPath** is designed to solve the "context window noise" problem. It ingests massive chat logs, processes them in intelligent batches, and iteratively builds a cumulative state of "Distilled Knowledge."

## 🚀 Features

- **Iterative Compression**: Processes long logs turn-by-turn, using the previous summary as context for the next batch.
- **Adaptive Backoff**: Robustly handles Gemini API rate limits (429) with exponential backoff and pre-emptive "cooling down" between batches.
- **Sliding Window Context**: Each batch sees the previous raw batch to prevent context loss at boundaries.
- **Cascading Updates**: Instructs the model to re-reason through the entire summary if a foundational step is changed later in the log.
- **Session Persistence**: Auto-saves your progress, API key, and settings to `localStorage`.
- **Advanced Controls**: Fine-tune batch size, token ceilings, and custom prompt templates.

## 🛠️ How it Works

1. **Upload**: Drag and drop a `.txt`, `.log`, or `.md` file (e.g., a long troubleshooting session with an AI).
2. **Batching**: The app splits the file into chunks based on "User/Gemini" turns and your preferred token ceiling.
3. **Distillation**: Gemini processes each batch, comparing the new data against the "Current Summary." It prunes failed attempts, replaces old fixes with new ones, and discards technical noise.
4. **Output**: You get a clean, actionable "How-To" guide or "Golden Path" that represents the final working state of the project.

## 📦 Installation & Setup

1. **Clone the repo**:
   ```bash
   git clone https://github.com/your-username/chat-log-distiller.git
   cd chat-log-distiller
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Run the dev server**:
   ```bash
   npm run dev
   ```

4. **API Key**: You'll need a Gemini API Key from [Google AI Studio](https://aistudio.google.com/).

## 📖 Use Cases & Modes

The app now features specialized **Processing Modes** to handle different types of long-form data:

- **Chat Log Distiller**: Prune dead ends and extract the "Golden Path" from messy technical troubleshooting logs.
- **Meeting Minutes & Tasks**: Extract executive summaries and categorized action items from long meeting transcripts.
- **Technical Doc Generator**: Synthesize raw developer notes, logs, and code snippets into structured technical documentation.

## 📄 License

MIT License - feel free to use this for your own projects!
